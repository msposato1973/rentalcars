package it.rentalcars.test;

import java.io.IOException;

import org.apache.http.client.ClientProtocolException;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws ClientProtocolException, IOException
    {
    	CarListClient carDao= new CarListClient();
       CarService carService = new CarService(carDao);
       Runnable consoleTask= () -> { 
    	   ConsoleConsumer consumer = new ConsoleConsumer(carService);
			consumer.begin();
    	   System.exit(0);
       };
       new Thread(consoleTask).start();
    }
}
