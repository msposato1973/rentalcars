package it.rentalcars.test;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CarBeanResponse {
	
	@JsonProperty("Search")
	private CarBeanSearchResponse search;

	public CarBeanSearchResponse getSearch() {
		return search;
	}

	public void setSearch(CarBeanSearchResponse search) {
		this.search = search;
	}

	
	
}
