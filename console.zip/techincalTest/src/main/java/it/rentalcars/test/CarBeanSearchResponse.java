package it.rentalcars.test;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CarBeanSearchResponse {
	@JsonProperty("VehicleList")
	private List<CarBean> vehicleList;

	public List<CarBean> getVehicleList() {
		return vehicleList;
	}

	public void setVehicleList(List<CarBean> vehicleList) {
		this.vehicleList = vehicleList;
	}
	
	

}
