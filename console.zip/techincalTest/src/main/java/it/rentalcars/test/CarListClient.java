package it.rentalcars.test;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.BasicHttpClientConnectionManager;

import com.fasterxml.jackson.databind.ObjectMapper;

public class CarListClient {

	ObjectMapper oMap= new ObjectMapper();



	private static class ScoredValue{
		private String value;
		private double score;

		public ScoredValue(String value, double score){
			this.value=value;
			this.score=score;
		}
		public String getValue() {
			return value;
		}
		public void setValue(String value) {
			this.value = value;
		}
		public double getScore() {
			return score;
		}
		public void setScore(double score) {
			this.score = score;
		}


	}

	private static Map<String,ScoredValue> carTypeMap=new HashMap<String,ScoredValue>();
	private static Map<String,ScoredValue> doorsMap=new HashMap<String,ScoredValue>();
	private static Map<String,ScoredValue> trasmissionMap=new HashMap<String,ScoredValue>();
	private static Map<String,ScoredValue> fuelMap=new HashMap<String,ScoredValue>();


	static {
		carTypeMap.put("M", new ScoredValue("Mini",0));
		carTypeMap.put("E", new ScoredValue("Economy",0));
		carTypeMap.put("C", new ScoredValue("Compact",0));
		carTypeMap.put("I", new ScoredValue("Intermediate",0));
		carTypeMap.put("S", new ScoredValue("Standard",0));
		carTypeMap.put("F", new ScoredValue("Full size",0));
		carTypeMap.put("P", new ScoredValue("Premium",0));
		carTypeMap.put("L", new ScoredValue("Luxury",0));
		carTypeMap.put("X", new ScoredValue("Special",0));
		doorsMap.put("B", new ScoredValue("2 doors",0));
		doorsMap.put("C", new ScoredValue("4 doors",0));
		doorsMap.put("D", new ScoredValue("5 doors",0));
		doorsMap.put("W", new ScoredValue("Estate",0));
		doorsMap.put("T", new ScoredValue("Convertible",0));
		doorsMap.put("F", new ScoredValue("SUV",0));
		doorsMap.put("P", new ScoredValue("Pick up",0));
		doorsMap.put("V", new ScoredValue("Passenger Van",0));
		trasmissionMap.put("M", new ScoredValue("Manual",1));
		trasmissionMap.put("A", new ScoredValue("Automatic",5));
		fuelMap.put("N", new ScoredValue("Petrol/no AC",0));
		fuelMap.put("R", new ScoredValue("Petrol/AC",2));

	}

	List<CarBean> carList;
	public CarListClient() throws ClientProtocolException, IOException{
		HttpClient client; 
		RequestConfig requestConfig;
		client=HttpClientBuilder.create().setConnectionManager(new BasicHttpClientConnectionManager()).build();
		requestConfig = RequestConfig.custom()
				.setConnectionRequestTimeout(30*1000)
				.setConnectTimeout(30*100)
				.setSocketTimeout(30*1000)
				.build();
		HttpGet request = new HttpGet("http://www.rentalcars.com/js/vehicles.json");
		request.setConfig(requestConfig);
		HttpResponse response;
		response = client.execute(request);
		CarBeanResponse parsedResponse=oMap.readValue(response.getEntity().getContent(), CarBeanResponse.class);
		carList=parsedResponse.getSearch().getVehicleList();
		carList.stream().forEach((element) -> {
			ScoredValue value;
			element.getSipp().substring(0,1);
			if ((value=carTypeMap.get(element.getSipp().substring(0,1)))!=null){
				element.setCarType(value.getValue());
			}
			if((value=doorsMap.get(element.getSipp().substring(1,2)))!=null){
				element.setDoors(value.getValue());
			}
			if((value=trasmissionMap.get(element.getSipp().substring(2, 3)))!=null){
				element.setTransmission(value.getValue());
				element.setCarRating(value.getScore());
			}
			if((value=fuelMap.get(element.getSipp().substring(3, 4)))!=null){
				element.setFuel(value.getValue());
				element.setCarRating(element.getCarRating()+value.getScore());
			}
			element.setTotalRating(element.getRating()+element.getCarRating());
		});
	}

	public List<CarBean> getCarList() {
		return carList;
	}

}
