package it.rentalcars.test;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class CarService {
	
	CarListClient carDao;

	public CarService(CarListClient carDao){
		this.carDao=carDao;
	}

	public List<CarBean> getCarList() {
		return carDao.getCarList().stream().sorted((a,b) -> {
			return (int)(a.getPrice()-b.getPrice());
		}).collect(Collectors.toList());
	}
	
	public  List<CarBean> getCarSpecs(){
		return carDao.getCarList()
//				.stream().sorted((a,b)->{
//			int comp=0;
//			if ((comp=a.getCarType().compareTo(b.getCarType()))==0){
//				comp=(int)(a.getRating()-b.getCarRating());
//			}
//			return comp;
//			
//		}).collect(Collectors.toList())
				;
	}
	
	public List<CarBean> getCarTopSupplier(){
		Map<String,List<CarBean>>  grouped=carDao.getCarList().stream().collect(Collectors.groupingBy(CarBean::getCarType,Collectors.toList()));
		List<CarBean> toReturn=grouped.entrySet().stream().filter(
	    (entry) ->{
	    	return entry.getValue()!=null && !entry.getValue().isEmpty();
	    }).map((entry)->{
	    	return entry.getValue().stream().collect(Collectors.maxBy((a,b)->{
				return (int)((a.getRating()-b.getRating())*10);
			})).get();
	    }).sorted((g,f)-> {
	    	return (int)((g.getCarRating()-f.getCarRating())*10);
	    }).collect(Collectors.toList());
		return toReturn;
	}

	public List<CarBean> getCarScores(){
		return carDao.getCarList().stream().sorted((a,b)->{
			return (int)((b.getTotalRating()-a.getTotalRating())*10);
		}).collect(Collectors.toList());
	}
	
}
