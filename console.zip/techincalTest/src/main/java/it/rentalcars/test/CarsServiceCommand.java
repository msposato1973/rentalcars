package it.rentalcars.test;

public enum CarsServiceCommand {
	
	
	ALL_CARS,
	CARS_SPECS,
	TOP_SUPPLIERS,
	CARS_SCORES,
	EXIT_COMMAND,
	INVALID_COMMAND,
	;

}
