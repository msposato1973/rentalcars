package it.rentalcars.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.stream.IntStream;

public class ConsoleConsumer {

	
	private CarService carService;
	
	private BufferedReader br;
	
	
	public ConsoleConsumer (CarService carService){
		this.carService = carService;
		this.br = new BufferedReader(new InputStreamReader(System.in));
	};
	
	
	public void printMenu(){
		System.out.println("++++++++++++ car rental service menu");
		System.out.println("1. Print cars list" );
		System.out.println("2. Print cars specifications");
		System.out.println("3. Print higest rated supplier per car type");
		System.out.println("4. Print cars score");
		System.out.println("5. Goodbye!");
	}
	
	public CarsServiceCommand parseCommand(){
		 CarsServiceCommand toReturn = CarsServiceCommand.INVALID_COMMAND;
		 try{
			 String read= br.readLine();
			 toReturn = CarsServiceCommand.values()[Integer.parseInt(read)-1];
		 }
		 catch (IndexOutOfBoundsException e){}
		 catch (NumberFormatException e){}
		 catch (IOException e) {
			 toReturn= CarsServiceCommand.EXIT_COMMAND;
		}
		
		 return toReturn;
	}
	
	public void prompt(){
		System.out.print("Choose: ");
	}
	public void printErrorCommand(){
		System.out.println("Invalid command");
	}
	
	public void printAllCars(List<CarBean> toPrint){
		IntStream.range(0,toPrint.size()).forEach((idx) ->{
			CarBean element=toPrint.get(idx);
			System.out.println(String.format("%s.%s - %s", String.valueOf(idx+1),element.getName(),String.valueOf(element.getPrice())));	
			
		});
	}
	
	public void printCarsSpecs(List<CarBean> toPrint){
		IntStream.range(0,toPrint.size()).forEach((idx) ->{
			CarBean element=toPrint.get(idx);
			System.out.println(String.format("%s.%s - %s - %s - %s - %s - %s", 
					String.valueOf(idx+1),
					element.getName(),
					element.getSipp(),
					element.getCarType(),
					element.getDoors(),
					element.getTransmission(),
					element.getFuel()
					));	
			
		});
	}
	
	public void printTopSuppliers(List<CarBean> toPrint){
		IntStream.range(0,toPrint.size()).forEach((idx) ->{
			CarBean element=toPrint.get(idx);
			System.out.println(String.format("%s.%s - %s - %s - %s", 
					String.valueOf(idx+1),
					element.getName(),
					element.getCarType(),
					element.getSupplier(),
					String.valueOf(element.getRating())
					));	
			
		});
	}
	
	public void printCarScores(List<CarBean> toPrint){
		IntStream.range(0,toPrint.size()).forEach((idx) ->{
			CarBean element=toPrint.get(idx);
			System.out.println(String.format("%s.%s - %s - %s - %s - %s", 
					String.valueOf(idx+1),
					element.getName(),
					element.getSipp(),
					String.valueOf(element.getCarRating()),
					String.valueOf(element.getRating()),
					String.valueOf(element.getTotalRating())
					));	
			
		});
	}
	
	public void begin() {
		CarsServiceCommand command = null;
		while (command!=CarsServiceCommand.EXIT_COMMAND){
			printMenu();
			prompt();
			command=parseCommand();
			switch (command){
			case ALL_CARS:
				printAllCars(carService.getCarList());
				break;
			case CARS_SCORES:
				printCarScores(carService.getCarScores());
				break;
			case CARS_SPECS:
				printCarsSpecs(carService.getCarSpecs());
				break;
			case EXIT_COMMAND:
				System.out.println(command.name());
				break;
			case TOP_SUPPLIERS:
				printTopSuppliers(carService.getCarTopSupplier());
				break;
			default:
				printErrorCommand();
			}
		}
	}
	
}
