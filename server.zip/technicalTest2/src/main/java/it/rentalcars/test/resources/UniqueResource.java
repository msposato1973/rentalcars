package it.rentalcars.test.resources;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import it.rentalcars.test.CarBean;
import it.rentalcars.test.CarService;

@Path("testRest")
@Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
@Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
public class UniqueResource {


	private CarService carServ;

	public UniqueResource(CarService carServ) {
		this.carServ = carServ;
	}
	
	@GET
	@Path("/first")
	public Response getPoint1(){
		ResponseBuilder toReturn = Response.ok();
		List<CarBean> entities=carServ.getCarList();
		toReturn.entity(entities);
		return toReturn.build();
	}
	
	@GET
	@Path("/second")
	public Response getPoint2(){
		ResponseBuilder toReturn = Response.ok();
		List<CarBean> entities=carServ.getCarSpecs();
		toReturn.entity(entities);
		return toReturn.build();
	}
	
	@GET
	@Path("/third")
	public Response getPointThree(){
		ResponseBuilder toReturn = Response.ok();
		List<CarBean> entities=carServ.getCarTopSupplier();
		toReturn.entity(entities);
		return toReturn.build();
	}
	@GET
	@Path("/fourth")
	public Response getPointFour() {
		ResponseBuilder toReturn = Response.ok();
		List<CarBean> entities=carServ.getCarScores();
		toReturn.entity(entities);
		return toReturn.build();
	}
	
	
}
