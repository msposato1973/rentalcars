package it.rentalcars.test;

import java.io.IOException;

import org.apache.http.client.ClientProtocolException;

import io.dropwizard.Application;
import io.dropwizard.setup.Bootstrap;
import io.dropwizard.setup.Environment;
import it.rentalcars.test.resources.UniqueResource;

public class technicalTest2Application extends Application<technicalTest2Configuration> {

    public static void main(final String[] args) throws Exception {
        new technicalTest2Application().run(args);
    }

    @Override
    public String getName() {
        return "technicalTest2";
    }

    @Override
    public void initialize(final Bootstrap<technicalTest2Configuration> bootstrap) {
        // TODO: application initialization
    }

    @Override
    public void run(final technicalTest2Configuration configuration,
                    final Environment environment) throws ClientProtocolException, IOException {
    	
    	CarListClient client = new CarListClient();
    	CarService carService= new CarService(client);
    	UniqueResource ur = new UniqueResource(carService);
    	environment.jersey().register(ur);
        Runnable consoleTask= () -> { 
     	   ConsoleConsumer consumer = new ConsoleConsumer(carService);
 			consumer.begin();
 			try {
				environment.getApplicationContext().getServer().stop();
			} catch (Exception e) {
				e.printStackTrace();
			}
        };
        new Thread(consoleTask).start();

    	
    }

}
